package com.jan.schooldatamanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jan.schooldatamanagement.dto.Teacher;
import com.jan.schooldatamanagement.repository.TeacherDAO;
import com.jan.schooldatamanagement.repository.TeacherDAOimp;
@WebServlet("/teacherlogin")
public class TeacherLogin extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		TeacherDAO dao = new TeacherDAOimp();
		Teacher teacherLogin = dao.TeacherLogin(email, password);
		PrintWriter writer = resp.getWriter();
		if(teacherLogin.getId()!=null) {
			writer.write(teacherLogin.toString());
		}
		else {
			writer.write("<h3>"+"Invalid UserName or Password "+"</h3>");
			writer.write("<h3>"+"To go back to Teacher login(<a href=teacherlogin.jsp>TeacherLogin</a>)"+"</h3>");
		}
	}

}
