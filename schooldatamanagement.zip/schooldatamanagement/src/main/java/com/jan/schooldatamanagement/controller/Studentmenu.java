package com.jan.schooldatamanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/studentmenu")
public class Studentmenu extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter writer = resp.getWriter();
		writer.write("<h1>"+" Welcome to the Studentmenu "+"</h1>");
		writer.write("<a href=StudentMenu.jsp >"+"To go to Studentmenu"+"<a>");
	}
	

}
