package com.jan.schooldatamanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.jan.schooldatamanagement.repository.*;
import com.jan.schooldatamanagement.dto.Admin;

@WebServlet("/updateadmin")
public class UpdateAdmin extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int id = Integer.parseInt(req.getParameter("id"));
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String dept = req.getParameter("department");
		String password = req.getParameter("password");
		
		AdminDAO dao = new AdminDAOimp();
		Admin admin = new Admin();
		admin.setId(id);
		admin.setName(name);
		admin.setEmail(email);
		admin.setDepartment(dept);
		admin.setPassword(password);
		
		PrintWriter writer = resp.getWriter();
		//writer.write("admin data is updated");
		writer.write(dao.updateAdmin(admin));
		
	}

}
