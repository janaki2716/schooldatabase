package com.jan.schooldatamanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jan.schooldatamanagement.dto.Teacher;
import com.jan.schooldatamanagement.repository.TeacherDAO;
import com.jan.schooldatamanagement.repository.TeacherDAOimp;

public class GetAllTeacher extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		TeacherDAO dao= new TeacherDAOimp();
		List<Teacher> allTeacher = dao.getAllTeacher();
		PrintWriter writer = resp.getWriter();
		for(Teacher t:allTeacher) {
			writer.write(t.toString());
			writer.write("<br>");
		}
	}

}
