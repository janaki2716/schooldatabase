package com.jan.schooldatamanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jan.schooldatamanagement.dto.Student;
import com.jan.schooldatamanagement.repository.StudentDAO;
import com.jan.schooldatamanagement.repository.StudentDAOimp;

@WebServlet("/studentlogin")
public class StudentLogin  extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		StudentDAO studentDAOimp = new StudentDAOimp();
		Student studentLogin = studentDAOimp.studentLogin(email, password);
		PrintWriter writer = resp.getWriter();
		if(studentLogin.getEmail().equals(email)&&studentLogin.getPassword().equals(password)) {
			RequestDispatcher rd = req.getRequestDispatcher("studentmenu");
			rd.forward(req, resp);
			
		}
		else {
			writer.write("<h5>"+"invalid username or password"+"</h5>");
			writer.write("<h3>"+"To go back to Studen tlogin(<a href=studentlogin.jsp>Student Login</a>)"+"</h3>");
		}
		
	}
	

}
