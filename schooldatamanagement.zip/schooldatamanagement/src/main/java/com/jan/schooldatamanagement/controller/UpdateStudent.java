package com.jan.schooldatamanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jan.schooldatamanagement.dto.Student;
import com.jan.schooldatamanagement.repository.StudentDAO;
import com.jan.schooldatamanagement.repository.StudentDAOimp;

@WebServlet("/updatestudent")
public class UpdateStudent extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int id = Integer.parseInt(req.getParameter("id"));
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		int std = Integer.parseInt(req.getParameter("studentid"));
		String sec = req.getParameter("section");
		Date dob = Date.valueOf(req.getParameter("dob"));
		String percentage = req.getParameter("throughtpercentage");
		String password = req.getParameter("password");
		
		StudentDAO dao = new StudentDAOimp();
		Student s  = new Student();
		s.setId(id);
		s.setName(name);
		s.setEmail(email);
		s.setStudentid(std);
		s.setSection(sec);
		s.setDateofbirth(dob);
		s.setThroughtpercentage(percentage);
		s.setPassword(password);
		
		PrintWriter writer = resp.getWriter();
		writer.write(dao.updateStudent(s));
	
	}

}
