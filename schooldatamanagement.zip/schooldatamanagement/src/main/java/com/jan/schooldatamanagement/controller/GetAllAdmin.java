package com.jan.schooldatamanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jan.schooldatamanagement.dto.Admin;
import com.jan.schooldatamanagement.repository.*;


//@WebServlet("/getalladmin")
public class GetAllAdmin extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		AdminDAO dao = new AdminDAOimp();
		List<Admin> allAdmin = dao.getAllAdmin();
		PrintWriter writer = resp.getWriter();
		for(Admin a:allAdmin) {
			writer.write(a.toString()+"/n");
			
		}
	}

}
