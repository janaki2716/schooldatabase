package com.jan.schooldatamanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jan.schooldatamanagement.dto.Teacher;
import com.jan.schooldatamanagement.repository.TeacherDAO;
import com.jan.schooldatamanagement.repository.TeacherDAOimp;
@WebServlet("/teacherlogin")
public class TeacherLogin extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		TeacherDAO dao = new TeacherDAOimp();
		Teacher teacherLogin = dao.TeacherLogin(email, password);
		PrintWriter writer = resp.getWriter();
		if(teacherLogin.getEmail().equals(email)&&teacherLogin.getPassword().equals(password)) {
			RequestDispatcher rd = req.getRequestDispatcher("teachermenu");
			rd.forward(req, resp);
		}
		else {
			writer.write("<h3>"+"Invalid UserName or Password "+"</h3>");
			writer.write("<a href=teacherlogin.jsp>"+"To go back tacherlogin"+"</h3>");
		}
	}

}
