package com.jan.schooldatamanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jan.schooldatamanagement.dto.Teacher;
import com.jan.schooldatamanagement.repository.TeacherDAO;
import com.jan.schooldatamanagement.repository.TeacherDAOimp;
@WebServlet("/saveteacher")
public class SaveTeacher extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int id = Integer.parseInt(req.getParameter("id"));
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String subject = req.getParameter("subject");
		double salary = Double.parseDouble(req.getParameter("salary"));
		Date dateofjoining = Date.valueOf(req.getParameter("doj"));
		String classteacher = req.getParameter("classteacher");
		String password = req.getParameter("password");
		TeacherDAO dao = new TeacherDAOimp();
		Teacher teacher = new Teacher();
		
		teacher.setId(id);
		teacher.setName(name);
		teacher.setEmail(email);
		teacher.setSubject(subject);
		teacher.setSalary(salary);
		teacher.setDateofjoining(dateofjoining);
		teacher.setClassTeacher(classteacher);
		teacher.setPassword(password);
		
		PrintWriter writer = resp.getWriter();
		writer.write(dao.saveTeacher(teacher));
		
	}

}
