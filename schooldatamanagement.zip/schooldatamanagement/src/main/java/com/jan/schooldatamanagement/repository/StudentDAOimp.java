package com.jan.schooldatamanagement.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;

import com.jan.schooldatamanagement.dto.Student;

public class StudentDAOimp implements StudentDAO{

	@Override
	public Student studentLogin(String email, String password) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/schooldatabase";
			String user="root";
			String pass="root";
			Connection connection=DriverManager.getConnection(url,user,pass);
			String query="select * from student where email=? and password=?";
			PreparedStatement ps = connection.prepareStatement(query);
			ps.setString(1, email);
			ps.setString(2, password);
			ResultSet set = ps.executeQuery();
			Student s = new Student();
			while(set.next()) {
				s.setId(set.getInt(1));
				s.setName(set.getString(2));
				s.setEmail(set.getString(3));
				s.setStudentid(set.getInt(4));
				s.setSection(set.getString(5));
				s.setDateofbirth(set.getDate(6));
				s.setThroughtpercentage(set.getString(7));
				s.setPassword(set.getString(8));
			}
			connection.close();
			return s;
		} catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		return null;
			
	}

	@Override
	public String saveStudent(Student student) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/schooldatabase";
			String user="root";
			String pass="root";
			Connection connection=DriverManager.getConnection(url,user,pass);
			String query="Insert into student values(?,?,?,?,?,?,?,?)";
			PreparedStatement ps = connection.prepareStatement(query);
			ps.setInt(1, student.getId());
			ps.setString(2, student.getName());
			ps.setString(3, student.getEmail());
			ps.setInt(4, student.getStudentid());
			ps.setString(5, student.getSection());
			ps.setDate(6, student.getDateofbirth());
			ps.setString(7, student.getThroughtpercentage());
			ps.setString(8, student.getPassword());
			int res = ps.executeUpdate();
			connection.close();
			return res+" row of Data Inserted";
		} catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		return "student data Not saved";
	}

	@Override
	public String updateStudent(Student student) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/schooldatabase";
			String user="root";
			String pass="root";
			Connection connection=DriverManager.getConnection(url,user,pass);
			String query="update student set name=?,email=?,studentid=?,section=?,dateofbirth=?,throughtpercentage=?,password=? where id=?";
			PreparedStatement ps = connection.prepareStatement(query);
			ps.setInt(8, student.getId());
			ps.setString(1, student.getName());
			ps.setString(2, student.getEmail());
			ps.setInt(3, student.getStudentid());
			ps.setString(4, student.getSection());
			ps.setDate(5, student.getDateofbirth());
			ps.setString(6, student.getThroughtpercentage());
			ps.setString(7, student.getPassword());
			int res = ps.executeUpdate();
			connection.close();
			return res+" row of Data updated";
		} catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		return "student data Not updated";
		
	}

	@Override
	public Student getStudentById(int id) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/schooldatabase";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			String query="SELECT * FROM student WHERE id=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);
			ResultSet set = ps.executeQuery();
			Student s=new Student();
			while(set.next()) {
				s.setId(set.getInt(1));
				s.setName(set.getString(2));
				s.setEmail(set.getString(3));
				s.setStudentid(set.getInt(4));
				s.setSection(set.getString(5));
				s.setDateofbirth(null);
				s.setThroughtpercentage(set.getString(7));
				s.setPassword(set.getString(8));
			}
			con.close();
			return s;
		} catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		return null;

	}

	@Override
	public List<Student> getAllStudent() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/schooldatabase";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			String query="SELECT * FROM student";
			PreparedStatement ps = con.prepareStatement(query);
			ResultSet set = ps.executeQuery();
			List<Student> list=null;
			if(set.isBeforeFirst()) {
				list=new ArrayList<>();
			}
			while(set.next()) {
				Student s=new Student();
				s.setId(set.getInt(1));
				s.setName(set.getString(2));
				s.setEmail(set.getString(3));
				s.setStudentid(set.getInt(4));
				s.setSection(set.getString(5));
				s.setDateofbirth(null);
				s.setThroughtpercentage(set.getString(7));
				s.setPassword(set.getString(8));
				list.add(s);
			}
			con.close();
			return list;
		} catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String deleteStudentById(int id) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/schooldatabase";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			String query="DELETE FROM student WHERE id=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);
			int r = ps.executeUpdate();
			con.close();
			return r+" row of Deleted";
		} catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		return null;

	}

}
