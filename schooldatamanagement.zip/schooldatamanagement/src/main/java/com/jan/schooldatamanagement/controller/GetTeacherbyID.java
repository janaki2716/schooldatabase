package com.jan.schooldatamanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jan.schooldatamanagement.dto.Teacher;
import com.jan.schooldatamanagement.repository.TeacherDAO;
import com.jan.schooldatamanagement.repository.TeacherDAOimp;

@WebServlet("/getteacherbyid")
public class GetTeacherbyID extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int id = Integer.parseInt(req.getParameter("id"));
		TeacherDAO dao = new TeacherDAOimp();
		Teacher teacherById = dao.getTeacherById(id);
		PrintWriter writer = resp.getWriter();
		writer.write(teacherById.toString());
		
	}

}
