package com.jan.schooldatamanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jan.schooldatamanagement.dto.Student;
import com.jan.schooldatamanagement.repository.StudentDAO;
import com.jan.schooldatamanagement.repository.StudentDAOimp;

public class GetAllStudents extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		StudentDAO dao = new StudentDAOimp();
		List<Student> allStudent = dao.getAllStudent();
		PrintWriter writer = resp.getWriter();
		for(Student s:allStudent) {
			writer.write(s.toString()+"/n");
		}
	}

}
